
<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8" />
    <link rel="stylesheet" href="css/style.css"/>
    <title>Carte</title>
<style>
	#map {
	height: 400px;
	width: 100%;
	}
	</style>
	</head>
	</head>

	<body>
		<?php include('static/header.php'); ?>
		<main>
			<?php include('static/menu.php'); ?>


			<div style="padding-left: 200px, width:80px, height:120px;text-align:center;padding-top:100px">
			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d44537.591614646946!2d4.88004424999998!3d45.75917499290812!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sfr!2sfr!4v1481192636762" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
			<?php include('static/footer.php'); ?>
			
			
		</main>	
	</body>
		



</html>
