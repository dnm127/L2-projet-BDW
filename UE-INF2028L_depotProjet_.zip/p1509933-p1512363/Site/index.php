<!-- Baptiste Jauseau p1509933 , Nhat Minh p1512363 -->


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
    <link rel="stylesheet" href="css/style.css"/>
    <title>Acceuil</title>
</head>

<body>
	<!--Inclusion de page , header , menu , accueil , footer -->
	<?php include('static/header.php'); ?>  
	<main>
		
		<?php include('static/menu.php'); ?>
		
		<?php include('static/acceuil.php'); ?>
	
	</main>
	
	<?php include('static/footer.php'); ?>

</body>

</html>
