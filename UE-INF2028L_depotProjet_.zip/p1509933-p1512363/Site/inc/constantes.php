<?php
	define('SERVEUR', 'localhost');
	define('UTILISATRICE', 'root'); // utilisatrice par défaut ('root')
	define('MOTDEPASSE', ''); // mot de passe par défaut (vide)
	define('BDD', 'bd_recette');
?>