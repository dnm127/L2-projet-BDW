<!DOCTYPE html>
<html>

<head>

	<meta charset="utf-8" />
	<link rel="stylesheet" href="css/style.css"/>
	<title>Formulaire Recette</title>
</head>

<body>

	<?php include('static/header.php'); ?>
	
	<main>
		<?php include('static/menu.php'); ?>
		<!-- Si l'ajout a la BD ne c'est pas faite correctement , alors affiche Erreur -->
		<div style="font-size:20;text-align :center;font-family: Gadugi;padding-top :100px;"> Erreur ! </div>

		

	</main>

	<?php include('static/footer.php'); ?>


</body>






</html>
