<!DOCTYPE html>

<html>
<head>
	<meta charset="utf-8" />
    <link rel="stylesheet" href="css/style.css"/>
    <title>Formulaire</title>
</head> 
	
	<!-- Definition de la page d'accueil , avec insertion d'une image 
	et d'un texte court -->
	<img src="img/photo.jpg" />
	<h1>Le projet du site</h1> 
			<div class="content"> 
				<p>Le site est tiré d’un projet informatique en deuxième année de licence informatique.
					Ce site a été créé par Bapiste Jauseau et Minh Nhat. 
					L’objet du site  est de crée une page aillant pour sujet les recettes de cuisines.
					Il doit permettre de voir les recettes déjà présentes mais aussi d’ajouter ces propres recettes avec ces propre ingrédient. 

			</p>
			</div>


	
	
	
	
	
	
</html> 