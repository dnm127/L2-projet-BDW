<nav> 
		<!-- Definition du menu et de son contenu -->  
		<ul class="menu"> 
		<li><h2><a href="index.php">Accueil</a></h2></li>
		<li><h2><a href="recette.php">Recettes & Ingredients</a></h2></li>
		<li><h2><a href="formulairer.php">Nouvelle recette</a></h2></li>
		<li><h2><a href="formulairei.php">Nouvel ingrédient</a></h2></li>
		<li><h2><a href="carte.php">Carte</a></h2></li>

		</ul>
</nav>