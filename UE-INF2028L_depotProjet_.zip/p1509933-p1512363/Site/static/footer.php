<footer> 
		 <!-- Insertion de deux lien en pied de page --> 
		 <a  href="http://www.univ-lyon1.fr/">UCBL Lyon </a> 
		 <a  href="http://liris.cnrs.fr/~fduchate/ens/BDW1/#td">BDW1</a> 
		
</footer>