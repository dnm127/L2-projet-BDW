<header id="banniere">
	
	<!-- Definition de l'entête , avec un logo et un titre -->
    <div style="float:left;">
        <a href="index.php">
        	<img src="img/logo.jpg" />
        </a>
    </div>
    
    <h1>Les recettes pratiques</h1>
    
</header>